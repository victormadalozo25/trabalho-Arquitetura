# Verificação experimental das hipóteses (PBL Etapa 02)

Arquivos novos (o baseline NÃO foi alterado; `processar_tarefa` é a mesma função):

| Arquivo | Para quê |
|---|---|
| `paralelo.py` | versão com **processos** ou **threads** (pool, maiores tarefas primeiro, resultados reordenados no fim, falhas tratadas como no baseline) |
| `comparar.py` | compara dois arquivos de resultados (conteúdo, ordem, tarefas inválidas) |
| `gerar_entradas.py` | cria `intensa.json`, `h2_escala.json` e `invalida.json` |
| `experimentos.py` | roda H1–H4 e a verificação de correção, grava um CSV por hipótese em `medicoes/` e o resumo em `outputs/experimentos/` |

## Passo a passo (no terminal, dentro da pasta do projeto; no Windows use `py` se `python` não existir)

1. `python gerar_entradas.py`
2. Ensaio rápido (1 min), só para ver se tudo roda: `python experimentos.py tudo --rapido`
   Depois apague os CSVs gerados em `medicoes/h*.csv` e `medicoes/correcao.csv` e a pasta `outputs/experimentos/`.
3. Feche navegador, vídeos, jogos, mensageiros. Deixe só o terminal. Notebook na tomada, sem modo economia.
4. Rode **uma hipótese por vez** (cada uma imprime uma tabela-resumo; tire o print DEPOIS da tabela aparecer):
   - `python experimentos.py h1`   → print `H1_resumo.png` (e `H1_gerenciador.png`, ver abaixo)
   - `python experimentos.py h2`   → print `H2_resumo.png`
   - `python experimentos.py h3`   → print `H3_resumo.png` (a tela rola por causa do log; o resumo também está salvo em `outputs/experimentos/resumo_h3.txt`)
   - `python experimentos.py h4`   → print `H4_resumo.png` (não mexa no computador durante a parte "ocioso")
   - `python experimentos.py correcao` → print `Correcao_resumo.png`
   Ou tudo de uma vez: `python experimentos.py tudo`
5. Print extra da H1 (Gerenciador de Tarefas): abra Ctrl+Shift+Esc → Desempenho → CPU → clique com o direito no gráfico → "Alterar gráfico para" → "Processadores lógicos". Rode `python main.py --entrada entradas/intensa.json --silencioso` e tire o print enquanto roda (um núcleo sobe, os outros ficam baixos; o Windows pode revezar qual núcleo). Depois rode `python paralelo.py --entrada entradas/intensa.json --modo processos --workers 8 --silencioso` e tire outro print (vários núcleos sobem).
6. Testes existentes: `python -m unittest discover -s tests -v` → print `Testes.png`.
7. Mande para o Claude: o conteúdo de `outputs/experimentos/resumo_h1.txt` … `resumo_h4.txt`, `resumo_correcao.txt` e os CSVs de `medicoes/`.

## Definições usadas (para o relatório)

- Trecho cronometrado: igual ao do baseline (só o processamento; leitura do JSON e gravação ficam fora). No paralelo conta da criação do pool até o fim da coleta/encerramento.
- Tempo total = relógio de parede (`perf_counter`). CPU = `process_time`; no modo processos soma principal + trabalhadores (medido dentro de cada trabalhador).
- Memória: pico do processo principal + pico de cada trabalhador (processos). Em threads, um só processo.
- Repetições: 5 (H1–H3), 10 sem carga + 5 com carga (H4). Estatística: mediana e mínimo–máximo.
- Alternância: a cada repetição todas as configurações rodam em sequência (A, B, C, A, B, C...), para que deriva de temperatura/ambiente atinja todas igualmente.
