"""Versão paralela (processos ou threads) usada nos experimentos do PBL.

Preserva o algoritmo do baseline: cada tarefa é executada pela MESMA função
``processar_tarefa`` de processador.py. Só muda a forma de executar.

Exemplos:
    python paralelo.py --entrada entradas/grande.json --modo processos --workers 4
    python paralelo.py --entrada entradas/grande.json --modo threads --workers 4

Trecho cronometrado (igual ao baseline): do momento em que o pool é criado até
todos os resultados terem sido coletados e o pool encerrado. Leitura do JSON e
gravação dos arquivos ficam FORA do cronômetro, como no baseline.

CPU e memória: no modo processos somam-se o processo principal e os processos
trabalhadores (CPU de cada tarefa medida dentro do trabalhador; pico de memória
= pico do principal + pico de cada trabalhador). No modo threads há um só
processo, então o process_time do principal já contém todas as threads.
"""

from __future__ import annotations

import argparse
import os
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
from pathlib import Path
from time import perf_counter, process_time
from typing import Any

from io_utils import carregar_tarefas, criar_logger, fechar_logger, gravar_json
from metricas import informacoes_ambiente, pico_memoria_processo_mib
from processador import processar_tarefa


def _tamanho(tarefa: Any) -> int:
    """Chave para enviar as maiores tarefas primeiro (inválidas valem 0)."""
    if isinstance(tarefa, dict):
        limite = tarefa.get("limite")
        if isinstance(limite, int) and not isinstance(limite, bool):
            return limite
    return 0


def _identificador(tarefa: Any, posicao: int) -> Any:
    if isinstance(tarefa, dict):
        return tarefa.get("id", f"posicao-{posicao}")
    return f"posicao-{posicao}"


def _executar_tarefa(posicao: int, tarefa: Any) -> dict[str, Any]:
    """Roda no trabalhador. Trata falhas do mesmo jeito que o baseline."""
    cpu_inicio = process_time()
    try:
        resultado = processar_tarefa(tarefa)
    except (TypeError, ValueError) as erro:
        resultado = {
            "id": _identificador(tarefa, posicao),
            "status": "falha",
            "erro": str(erro),
        }
    return {
        "posicao": posicao,
        "resultado": resultado,
        "cpu": process_time() - cpu_inicio,
        "pid": os.getpid(),
        "pico_mib": pico_memoria_processo_mib(),
    }


def executar_paralelo(
    entrada: Path,
    saida_resultados: Path,
    saida_metricas: Path,
    saida_log: Path,
    modo: str = "processos",
    workers: int = 2,
    verbose: bool = True,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if modo not in ("processos", "threads"):
        raise ValueError("modo deve ser 'processos' ou 'threads'")
    logger = criar_logger(saida_log, verbose=verbose)
    tarefas = carregar_tarefas(entrada)
    logger.info("Execução paralela (%s, %d workers) iniciada", modo, workers)
    logger.info("Tarefas recebidas: %d", len(tarefas))

    # maiores primeiro; sorted é estável, então empates mantêm a ordem original
    ordem_envio = sorted(range(len(tarefas)), key=lambda i: -_tamanho(tarefas[i]))
    resultados: list[Any] = [None] * len(tarefas)
    cpu_trabalhadores = 0.0
    picos: dict[int, float] = {}

    Executor = ProcessPoolExecutor if modo == "processos" else ThreadPoolExecutor
    inicio = perf_counter()
    cpu_inicio = process_time()
    with Executor(max_workers=workers) as executor:
        futuros = [executor.submit(_executar_tarefa, i + 1, tarefas[i]) for i in ordem_envio]
        for futuro in as_completed(futuros):
            dado = futuro.result()
            resultados[dado["posicao"] - 1] = dado["resultado"]
            cpu_trabalhadores += dado["cpu"]
            if dado["pico_mib"] is not None:
                picos[dado["pid"]] = max(picos.get(dado["pid"], 0.0), dado["pico_mib"])
            logger.info("Tarefa %s finalizada", dado["resultado"].get("id"))
    tempo_total = perf_counter() - inicio
    cpu_principal = process_time() - cpu_inicio

    pico_principal = pico_memoria_processo_mib() or 0.0
    if modo == "processos":
        tempo_cpu = cpu_principal + cpu_trabalhadores
        pico_total = pico_principal + sum(v for pid, v in picos.items() if pid != os.getpid())
    else:
        tempo_cpu = cpu_principal
        pico_total = pico_principal

    falhas = sum(1 for r in resultados if r.get("status") == "falha")
    concluidas = len(tarefas) - falhas
    resumo = {
        "modo_execucao": modo,
        "workers": workers,
        "arquivo_entrada": str(entrada),
        "tarefas_recebidas": len(tarefas),
        "tarefas_concluidas": concluidas,
        "falhas": falhas,
        "tempo_total_segundos": round(tempo_total, 6),
        "tempo_cpu_segundos": round(tempo_cpu, 6),
        "pico_memoria_total_mib": round(pico_total, 3),
        "vazao_tarefas_por_segundo": round(concluidas / tempo_total, 3) if tempo_total > 0 else 0.0,
        "ordem_de_envio": [_identificador(tarefas[i], i + 1) for i in ordem_envio],
        "ambiente": informacoes_ambiente(),
    }
    gravar_json(saida_resultados, resultados)
    gravar_json(saida_metricas, resumo)
    logger.info("Tempo total: %.6f s | CPU somada: %.6f s", tempo_total, tempo_cpu)
    fechar_logger(logger)
    return resultados, resumo


def main() -> int:
    p = argparse.ArgumentParser(description="Versão paralela do baseline (PBL).")
    p.add_argument("--entrada", type=Path, default=Path("entradas/pequena.json"))
    p.add_argument("--modo", choices=["processos", "threads"], default="processos")
    p.add_argument("--workers", type=int, default=os.cpu_count() or 2)
    p.add_argument("--silencioso", action="store_true")
    a = p.parse_args()
    nome = f"{a.entrada.stem}_{a.modo}_{a.workers}"
    _, r = executar_paralelo(
        a.entrada,
        Path("outputs") / f"resultados_{nome}.json",
        Path("outputs") / f"metricas_{nome}.json",
        Path("logs") / f"execucao_{nome}.log",
        modo=a.modo, workers=a.workers, verbose=not a.silencioso,
    )
    print("\nResumo")
    for k in ("modo_execucao", "workers", "tarefas_concluidas", "falhas",
              "tempo_total_segundos", "tempo_cpu_segundos", "pico_memoria_total_mib",
              "vazao_tarefas_por_segundo"):
        print(f"  {k}: {r[k]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
