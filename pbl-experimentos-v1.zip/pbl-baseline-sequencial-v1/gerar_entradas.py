"""Gera entradas extras para os experimentos (rode uma vez).

- intensa.json: 16 tarefas, limites 460000..610000 (faixa do Anexo A; a lista
  exata não foi fornecida, usamos passo de 10000, igual às outras cargas).
- h2_escala.json: limites bem espalhados para medir como o custo cresce.
- invalida.json: mistura tarefas válidas e inválidas.
"""

import json
from pathlib import Path

pasta = Path("entradas")
pasta.mkdir(exist_ok=True)

def salvar(nome, dados):
    (pasta / nome).write_text(json.dumps(dados, ensure_ascii=False, indent=2), encoding="utf-8")
    print("gerado", pasta / nome)

salvar("intensa.json", [{"id": f"I-{i+1:02d}", "limite": 460000 + 10000 * i} for i in range(16)])
salvar("h2_escala.json", [{"id": f"E-{i+1:02d}", "limite": l} for i, l in
                          enumerate([25000, 50000, 100000, 200000, 400000, 600000])])
salvar("invalida.json", [
    {"id": "V-01", "limite": 50000},
    {"id": "V-02"},
    {"id": "V-03", "limite": -5},
    {"id": "V-04", "limite": "abc"},
    {"limite": 1000},
    "texto solto",
    {"id": "V-07", "limite": 120000},
    {"id": "V-08", "limite": 80000},
])
