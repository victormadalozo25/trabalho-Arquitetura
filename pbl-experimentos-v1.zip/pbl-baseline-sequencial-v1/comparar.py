"""Compara resultados de duas execuções: conteúdo, ordem e tarefas inválidas.

Ignora apenas ``duracao_segundos`` (varia a cada execução).
    python comparar.py outputs/resultados_a.json outputs/resultados_b.json
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any


def comparar(a: list[dict[str, Any]], b: list[dict[str, Any]]) -> tuple[bool, str]:
    if len(a) != len(b):
        return False, f"quantidade diferente ({len(a)} x {len(b)})"
    if [r.get("id") for r in a] != [r.get("id") for r in b]:
        return False, "ordem dos ids diferente"
    for i, (x, y) in enumerate(zip(a, b), start=1):
        xx = {k: v for k, v in x.items() if k != "duracao_segundos"}
        yy = {k: v for k, v in y.items() if k != "duracao_segundos"}
        if xx != yy:
            return False, f"posição {i}: {xx} != {yy}"
    falhas = sum(1 for r in a if r.get("status") == "falha")
    return True, f"idênticos ({len(a)} resultados, {falhas} falhas iguais, mesma ordem)"


def main() -> int:
    if len(sys.argv) != 3:
        print(__doc__)
        return 2
    a = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    b = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
    ok, msg = comparar(a, b)
    print(("OK: " if ok else "DIFERENTE: ") + msg)
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
