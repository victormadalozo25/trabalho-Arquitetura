"""Experimentos das hipóteses H1-H4 do Relatório Técnico 01.

Uso (na pasta do projeto):
    python gerar_entradas.py            # uma vez
    python experimentos.py tudo --rapido   # ensaio de 1 minuto (confere se roda)
    python experimentos.py h1           # ou h2, h3, h4, correcao
    python experimentos.py tudo         # tudo de uma vez (uns minutos)

Cada execução vira uma linha em medicoes/h*.csv. O resumo de cada hipótese é
impresso na tela (para o print) e salvo em outputs/experimentos/resumo_h*.txt.
"""

from __future__ import annotations

import argparse
import csv
import math
import multiprocessing as mp
import os
import statistics as st
import sys
from datetime import datetime
from pathlib import Path
from time import perf_counter

from comparar import comparar
from io_utils import carregar_tarefas, gravar_json
from main import executar_baseline
from metricas import informacoes_ambiente
from paralelo import executar_paralelo

RAIZ = Path(__file__).resolve().parent
EXP = RAIZ / "outputs" / "experimentos"
MED = RAIZ / "medicoes"
ENT = RAIZ / "entradas"


# ---------------------------------------------------------------- utilidades
def registrar(arquivo: str, linha: dict) -> None:
    MED.mkdir(exist_ok=True)
    caminho = MED / arquivo
    novo = not caminho.exists()
    with caminho.open("a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(linha))
        if novo:
            w.writeheader()
        w.writerow(linha)


class Saida:
    """Imprime e guarda o texto do resumo."""
    def __init__(self, nome: str):
        self.nome, self.linhas = nome, []
    def __call__(self, texto: str = "") -> None:
        print(texto)
        self.linhas.append(texto)
    def salvar(self) -> None:
        EXP.mkdir(parents=True, exist_ok=True)
        (EXP / f"resumo_{self.nome}.txt").write_text("\n".join(self.linhas), encoding="utf-8")


def agora() -> str:
    return datetime.now().isoformat(timespec="seconds")


def baseline(entrada: str, tag: str, verbose: bool = False):
    EXP.mkdir(parents=True, exist_ok=True)
    inicio = perf_counter()
    res, resumo = executar_baseline(
        entrada=ENT / f"{entrada}.json",
        saida_resultados=EXP / f"res_{tag}.json",
        saida_metricas=EXP / f"met_{tag}.json",
        saida_log=EXP / f"log_{tag}.log",
        verbose=verbose,
    )
    return res, resumo, perf_counter() - inicio


def paralelo(entrada: str, tag: str, modo: str, workers: int):
    EXP.mkdir(parents=True, exist_ok=True)
    return executar_paralelo(
        ENT / f"{entrada}.json",
        EXP / f"res_{tag}.json", EXP / f"met_{tag}.json", EXP / f"log_{tag}.log",
        modo=modo, workers=workers, verbose=False,
    )


def med(v): return st.median(v)
def cv(v): return (st.stdev(v) / st.mean(v) * 100) if len(v) > 1 else 0.0
def faixa(v): return f"{min(v):.4f} – {max(v):.4f}"


def reta_loglog(xs, ys):
    lx, ly = [math.log(x) for x in xs], [math.log(y) for y in ys]
    mx, my = st.mean(lx), st.mean(ly)
    sxx = sum((a - mx) ** 2 for a in lx)
    sxy = sum((a - mx) * (b - my) for a, b in zip(lx, ly))
    b = sxy / sxx
    a = my - b * mx
    ss_res = sum((y - (a + b * x)) ** 2 for x, y in zip(lx, ly))
    ss_tot = sum((y - my) ** 2 for y in ly)
    return b, (1 - ss_res / ss_tot if ss_tot else 1.0)


def cabecalho(s: Saida, titulo: str) -> None:
    amb = informacoes_ambiente()
    s("=" * 72)
    s(titulo)
    s(f"Data: {agora()} | Python {amb['python']} | {amb['sistema_operacional']} | CPUs lógicas: {amb['cpus_logicas']}")
    s("=" * 72)


# ------------------------------------------------------------------- H1
def h1(rep: int, entrada: str, workers: list[int]) -> None:
    s = Saida("h1")
    cabecalho(s, f"H1 – o gargalo é a CPU em um único núcleo | entrada={entrada} | repetições={rep}")
    configs = [("sequencial", 1)] + [("processos", n) for n in workers] + [("threads", max(workers))]
    dados: dict[tuple, list] = {c: [] for c in configs}
    referencia = None
    for r in range(1, rep + 1):
        for versao, n in configs:                       # alterna as versões a cada repetição
            if versao == "sequencial":
                res, m, _ = baseline(entrada, f"h1_seq_{r}")
                referencia = referencia or res
                pico = m["pico_memoria_processo_mib"]
            else:
                res, m = paralelo(entrada, f"h1_{versao}{n}_{r}", versao, n)
                pico = m["pico_memoria_total_mib"]
            ok, msg = comparar(referencia, res)
            linha = dict(hipotese="H1", execucao=r, entrada=entrada, versao=versao, workers=n,
                         tempo_total_s=m["tempo_total_segundos"], tempo_cpu_s=m["tempo_cpu_segundos"],
                         razao_cpu_sobre_total=round(m["tempo_cpu_segundos"] / m["tempo_total_segundos"], 3),
                         pico_memoria_mib=pico, vazao_tarefas_s=m["vazao_tarefas_por_segundo"],
                         resultado_identico=ok, momento=agora())
            registrar("h1_execucoes.csv", linha)
            dados[(versao, n)].append(linha)
            print(f"  rep {r} {versao:10s} N={n:2d}: total={m['tempo_total_segundos']:.3f}s cpu={m['tempo_cpu_segundos']:.3f}s identico={ok}")
    t_seq = med([x["tempo_total_s"] for x in dados[("sequencial", 1)]])
    s()
    s(f"{'versão':10s} {'N':>3s} {'mediana(s)':>11s} {'min–max (s)':>18s} {'CPU/total':>9s} {'speedup':>8s} {'efic.':>6s} {'mem(MiB)':>9s} {'idênticos':>9s}")
    for (versao, n), linhas in dados.items():
        tt = [x["tempo_total_s"] for x in linhas]
        sp = t_seq / med(tt)
        s(f"{versao:10s} {n:3d} {med(tt):11.4f} {faixa(tt):>18s} "
          f"{med([x['razao_cpu_sobre_total'] for x in linhas]):9.2f} {sp:8.2f} {sp / n:6.2f} "
          f"{med([x['pico_memoria_mib'] or 0 for x in linhas]):9.1f} "
          f"{sum(x['resultado_identico'] for x in linhas)}/{len(linhas)}")
    s()
    s("Como ler: no sequencial, CPU/total perto de 1,0 = um núcleo ocupado o tempo todo (CPU-bound).")
    s("Se processos com N>1 reduzem muito o tempo e threads quase não reduzem, há núcleos livres")
    s("e o limite do baseline era a execução em um só núcleo (GIL impede ganho com threads).")
    s("Faça também o print do Gerenciador de Tarefas (ver README_EXPERIMENTOS.md).")
    s.salvar()


# ------------------------------------------------------------------- H2
def h2(rep: int, entradas: list[str]) -> None:
    s = Saida("h2")
    cabecalho(s, f"H2 – custo por tarefa cresce com limite^1,5 | entradas={entradas} | repetições={rep}")
    por_limite: dict[int, list[float]] = {}
    totais: dict[str, list[float]] = {e: [] for e in entradas}
    for r in range(1, rep + 1):
        for e in entradas:
            res, m, _ = baseline(e, f"h2_{e}_{r}")
            totais[e].append(m["tempo_total_segundos"])
            registrar("h2_totais.csv", dict(hipotese="H2", execucao=r, entrada=e,
                      tempo_total_s=m["tempo_total_segundos"], momento=agora()))
            for x in res:
                por_limite.setdefault(x["limite"], []).append(x["duracao_segundos"])
                registrar("h2_tarefas.csv", dict(hipotese="H2", execucao=r, entrada=e, id=x["id"],
                          limite=x["limite"], duracao_s=x["duracao_segundos"],
                          quantidade_primos=x["quantidade_primos"], momento=agora()))
            print(f"  rep {r} {e}: total={m['tempo_total_segundos']:.3f}s")
    limites = sorted(por_limite)
    medianas = [med(por_limite[l]) for l in limites]
    expoente, r2 = reta_loglog(limites, medianas)
    l0, t0 = limites[0], medianas[0]
    s()
    s(f"{'limite':>8s} {'mediana(s)':>11s} {'min–max(s)':>20s} {'previsto 1,5':>13s} {'erro':>7s}")
    for l, t in zip(limites, medianas):
        prev = t0 * (l / l0) ** 1.5
        s(f"{l:8d} {t:11.4f} {faixa(por_limite[l]):>20s} {prev:13.4f} {100 * (t - prev) / prev:6.1f}%")
    s()
    s(f"Expoente ajustado (reta em escala log-log): {expoente:.3f}  | R² = {r2:.4f}  | esperado pelo modelo: 1,5")
    s("Nota: pela teoria, o custo é ~ L^1,5 / ln(L) (a densidade de primos cai com L),")
    s("então o expoente medido tende a ficar um pouco abaixo de 1,5.")
    if {"pequena", "intensa"} <= set(entradas):
        razao = med(totais["intensa"]) / med(totais["pequena"])
        tp, ti = carregar_tarefas(ENT / "pequena.json"), carregar_tarefas(ENT / "intensa.json")
        for nome, e_ in (("1,5", 1.5), (f"{expoente:.2f}", expoente)):
            prev = sum(t["limite"] ** e_ for t in ti) / sum(t["limite"] ** e_ for t in tp)
            s(f"Razão intensa/pequena prevista com expoente {nome}: {prev:5.1f}x")
        s(f"Razão intensa/pequena medida (medianas dos tempos totais): {razao:5.1f}x")
    s.salvar()


# ------------------------------------------------------------------- H3
def h3(rep: int, entrada: str) -> None:
    s = Saida("h3")
    cabecalho(s, f"H3 – leitura, gravação e log custam pouco | entrada={entrada} | repetições={rep}")
    caminho = ENT / f"{entrada}.json"
    linhas = {"com_log": [], "sem_log": []}
    for r in range(1, rep + 1):
        for nome, verbose in (("com_log", True), ("sem_log", False)):   # alterna
            t0 = perf_counter(); carregar_tarefas(caminho); t_leitura = perf_counter() - t0
            res, m, t_ponta = baseline(entrada, f"h3_{nome}_{r}", verbose=verbose)
            t0 = perf_counter(); gravar_json(EXP / "h3_tmp_resultados.json", res)
            gravar_json(EXP / "h3_tmp_metricas.json", m); t_grav = perf_counter() - t0
            laco = m["tempo_total_segundos"]
            linha = dict(hipotese="H3", execucao=r, entrada=entrada, condicao=nome,
                         tempo_ponta_a_ponta_s=round(t_ponta, 6), tempo_laco_s=laco,
                         tempo_leitura_s=round(t_leitura, 6), tempo_gravacao_s=round(t_grav, 6),
                         fracao_fora_do_calculo_pct=round(100 * (t_ponta - laco) / t_ponta, 3),
                         momento=agora())
            registrar("h3_execucoes.csv", linha)
            linhas[nome].append(linha)
            print(f"  [rep {r} {nome}] ponta-a-ponta={t_ponta:.4f}s laço={laco:.4f}s", file=sys.stderr)
    s()
    s(f"{'condição':8s} {'ponta-a-ponta(s)':>17s} {'laço(s)':>9s} {'leitura(s)':>11s} {'gravação(s)':>12s} {'fora do cálculo':>16s}")
    for nome, ls in linhas.items():
        s(f"{nome:8s} {med([x['tempo_ponta_a_ponta_s'] for x in ls]):17.4f} {med([x['tempo_laco_s'] for x in ls]):9.4f} "
          f"{med([x['tempo_leitura_s'] for x in ls]):11.5f} {med([x['tempo_gravacao_s'] for x in ls]):12.5f} "
          f"{med([x['fracao_fora_do_calculo_pct'] for x in ls]):15.2f}%")
    a, b = (med([x["tempo_laco_s"] for x in linhas[k]]) for k in ("com_log", "sem_log"))
    s()
    s(f"Diferença do laço com log x sem log: {100 * (a - b) / b:+.2f}% (positivo = log deixa mais lento)")
    s("Se leitura + gravação + log somarem poucos % do total, H3 é sustentada.")
    s.salvar()


# ------------------------------------------------------------------- H4
def _carga_fundo(parar) -> None:
    while not parar.is_set():
        for _ in range(200000):
            pass


def h4(rep: int, rep_carga: int, entrada: str, hogs: int) -> None:
    s = Saida("h4")
    cabecalho(s, f"H4 – variação vem do ambiente | entrada={entrada} | repetições ocioso={rep}, com carga={rep_carga}")
    grupos: dict[str, list[dict]] = {"ocioso": [], "carga_de_fundo": []}
    contagens = set()

    def rodar(cond: str, n: int):
        for r in range(1, n + 1):
            res, m, _ = baseline(entrada, f"h4_{cond}_{r}")
            contagens.add(tuple(x["quantidade_primos"] for x in res))
            linha = dict(hipotese="H4", execucao=r, entrada=entrada, condicao=cond,
                         processos_de_fundo=0 if cond == "ocioso" else hogs,
                         tempo_total_s=m["tempo_total_segundos"], tempo_cpu_s=m["tempo_cpu_segundos"],
                         momento=agora())
            registrar("h4_execucoes.csv", linha)
            grupos[cond].append(linha)
            print(f"  [{cond}] rep {r}: total={m['tempo_total_segundos']:.3f}s cpu={m['tempo_cpu_segundos']:.3f}s")

    rodar("ocioso", rep)
    parar = mp.Event()
    procs = [mp.Process(target=_carga_fundo, args=(parar,), daemon=True) for _ in range(hogs)]
    for p in procs: p.start()
    try:
        rodar("carga_de_fundo", rep_carga)
    finally:
        parar.set()
        for p in procs: p.join(timeout=5)
    s()
    s(f"{'condição':15s} {'n':>3s} {'mediana(s)':>11s} {'min–max(s)':>20s} {'máx/mín':>8s} {'CV':>7s}")
    for cond, ls in grupos.items():
        t = [x["tempo_total_s"] for x in ls]
        s(f"{cond:15s} {len(t):3d} {med(t):11.4f} {faixa(t):>20s} {max(t) / min(t):8.2f} {cv(t):6.2f}%")
    s()
    s(f"Resultado (quantidade de primos por tarefa) idêntico em todas as execuções: {len(contagens) == 1}")
    s(f"Processos de fundo na condição com carga: {hogs}")
    s("Como o algoritmo e os resultados são os mesmos, a variação só pode vir do ambiente.")
    s("Compare com o Anexo A (grande: 11,47 a 16,03 s, máx/mín = 1,40).")
    s.salvar()


# ------------------------------------------------------------- correção
def correcao(entradas: list[str], workers: int) -> None:
    s = Saida("correcao")
    cabecalho(s, f"Verificação de correção (baseline x paralelo) | workers={workers}")
    s(f"{'entrada':10s} {'versão':10s} {'resultado':10s} detalhe")
    for e in entradas:
        ref, _, _ = baseline(e, f"cor_{e}_seq")
        for modo in ("processos", "threads"):
            res, _ = paralelo(e, f"cor_{e}_{modo}", modo, workers)
            ok, msg = comparar(ref, res)
            s(f"{e:10s} {modo:10s} {'OK' if ok else 'DIFERENTE':10s} {msg}")
            registrar("correcao.csv", dict(entrada=e, versao=modo, workers=workers,
                      identico=ok, detalhe=msg, momento=agora()))
    s("Compara id, limite, quantidade_primos, status, erro e ORDEM (ignora duracao_segundos).")
    s("A entrada 'invalida' contém tarefas inválidas: elas devem aparecer como falha nos dois lados.")
    s.salvar()


# ------------------------------------------------------------------ main
def main() -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("experimento", choices=["h1", "h2", "h3", "h4", "correcao", "tudo"])
    p.add_argument("--repeticoes", type=int, default=5)
    p.add_argument("--repeticoes-h4", type=int, default=10)
    p.add_argument("--entrada", default="grande")
    p.add_argument("--workers", type=int, nargs="+", default=[2, 4, 8])
    p.add_argument("--carga-fundo", type=int, default=os.cpu_count() or 4)
    p.add_argument("--rapido", action="store_true", help="ensaio curto com a carga pequena (só para conferir)")
    a = p.parse_args()
    if a.rapido:
        a.entrada, a.repeticoes, a.repeticoes_h4, a.workers = "pequena", 2, 2, [2]
        a.carga_fundo = min(a.carga_fundo, 4)
    sel = ["h1", "h2", "h3", "h4", "correcao"] if a.experimento == "tudo" else [a.experimento]
    for e in sel:
        if e == "h1": h1(a.repeticoes, a.entrada, a.workers)
        if e == "h2":
            h2(a.repeticoes, ["pequena"] if a.rapido else ["pequena", "media", "grande", "intensa", "h2_escala"])
        if e == "h3": h3(a.repeticoes, a.entrada)
        if e == "h4": h4(a.repeticoes_h4, max(3, a.repeticoes) if not a.rapido else 2, a.entrada, a.carga_fundo)
        if e == "correcao":
            correcao(["pequena", "invalida"] if a.rapido else ["pequena", "media", "grande", "invalida"], max(a.workers))
    return 0


if __name__ == "__main__":
    mp.freeze_support()
    raise SystemExit(main())
